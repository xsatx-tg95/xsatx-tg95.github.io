import sys
l1lll_thegroove=sys.version_info[0]==2
l1l111_thegroove=2048
l1ll11l_thegroove=7
def l1_thegroove(l1111_thegroove):
 global l1l11ll_thegroove
 l1ll1_thegroove=ord(l1111_thegroove[-1])
 l11lll1_thegroove=l1111_thegroove[:-1]
 l111_thegroove=l1ll1_thegroove%len(l11lll1_thegroove)
 l11l11_thegroove=l11lll1_thegroove[:l111_thegroove]+l11lll1_thegroove[l111_thegroove:]
 if l1lll_thegroove:
  l11lll_thegroove=l1ll1l_thegroove().join([l11llll_thegroove(ord(char)-l1l111_thegroove-(l11ll1l_thegroove+l1ll1_thegroove)%l1ll11l_thegroove)for l11ll1l_thegroove,char in enumerate(l11l11_thegroove)])
 else:
  l11lll_thegroove=str().join([chr(ord(char)-l1l111_thegroove-(l11ll1l_thegroove+l1ll1_thegroove)%l1ll11l_thegroove)for l11ll1l_thegroove,char in enumerate(l11l11_thegroove)])
 return eval(l11lll_thegroove)
import base64
import hashlib
import os
import sys
import random
l1l1l11_thegroove=False
try:
 from Cryptodome.Cipher import AES
 import resources.lib.pyaes.aes as pyaes
except:
 import resources.lib.pyaes.aes as pyaes
 l1l1l11_thegroove=True
import inspect
from datetime import datetime
try:
 from zoneinfo import ZoneInfo
except:
 from backports.zoneinfo import ZoneInfo
try:
 import xbmc
 import xbmcaddon
 import xbmcgui
 import xbmcvfs
except:
 pass
class Token:
 def __init__(self):
  self.name=l1_thegroove(u"ࠣࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡵࡪࡨ࡫ࡷࡵ࡯ࡷࡧ࠶࠺࠵ࠨ࣏")
  self.token=l1_thegroove(u"ࠤ࣐ࠥ")
  self.l1l1ll_thegroove=l1_thegroove(u"ࠥ࠷࠸࠸ࡓࡆࡅࡕࡉ࡙ࡧࡢࡤ࠳࠵࠷࠹ࠨ࣑")
  self.l111l1_thegroove=l1_thegroove(u"࡙ࠦ࡮ࡥࡨࡴࡲࡳࡻ࡫ࠠ࠴࠸࠳࣒ࠦ")
  self.result=l1_thegroove(u"ࠧࠨ࣓")
  self.l1ll_thegroove=0
  self.l1l1l11_thegroove=l1l1l11_thegroove
 def l1l1111_thegroove(self):
  __caller__=inspect.stack()[1].function
  self.l1l11l_thegroove(__caller__)
  l1l1111l1_thegroove=l1_thegroove(u"ࠨࡅࡶࡴࡲࡴࡪ࠵ࡒࡰ࡯ࡨࠦࣔ")
  l1l11l11l_thegroove=datetime.now(ZoneInfo(l1l1111l1_thegroove))
  l11llllll_thegroove=datetime.timestamp(l1l11l11l_thegroove)
  return int(l11llllll_thegroove)
 def l1l11l1_thegroove(self,l1ll111_thegroove):
  __caller__=inspect.stack()[1].function
  self.l1l11l_thegroove(__caller__)
  l1l1_thegroove=self.l1l11l111_thegroove(l1_thegroove(u"ࠢࡪࡶࡨࡱࡤࡶࡡࡳࡵࡨࡶ࠳ࡶࡹࠣࣕ"))
  l1111l_thegroove=len(open(l1l1_thegroove).read().splitlines())
  l11111_thegroove=l1ll111_thegroove%l1111l_thegroove
  self.l1ll_thegroove=l11111_thegroove
  return l11111_thegroove
 def l1l11l111_thegroove(self,name):
  try:
   __addon__=xbmcaddon.Addon(id=self.name)
   if sys.version_info[0]<3:
    cwd=xbmc.translatePath(__addon__.getAddonInfo(l1_thegroove(u"ࠨࡲࡤࡸ࡭࠭ࣖ")))
   else:
    cwd=xbmcvfs.translatePath(__addon__.getAddonInfo(l1_thegroove(u"ࠩࡳࡥࡹ࡮ࠧࣗ")))
  except:
   cwd=os.getcwd()+l1_thegroove(u"ࠥ࠳ࡹ࡫ࡳࡵࠤࣘ")
  path=(l1_thegroove(u"ࠦࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠬ࡮ࡱࡧࡹࡱ࡫ࡳ࠭ࠤࣙ")+name).split(l1_thegroove(u"ࠧ࠲ࠢࣚ"))
  l1l1_thegroove=cwd+os.sep+os.path.join(*path)
  return l1l1_thegroove
 @staticmethod
 def l1l111l_thegroove(l1lll1l_thegroove,l11111_thegroove):
  try:
   with open(l1lll1l_thegroove,l1_thegroove(u"࠭ࡲࠨࣛ"))as f:
    for line_number,line in enumerate(f):
     if line_number==l11111_thegroove:
      return str(line).strip()
  except Exception as e:
   pass
 def set_token(self):
  if not self.l1ll11_thegroove():
   return None
  try:
   l1ll111_thegroove=self.l1l1111_thegroove()
   line=self.l1l11l1_thegroove(l1ll111_thegroove)
   l1l111111_thegroove=str(len(str(line)))+str(line)
   n=(6-len(l1l111111_thegroove))
   l11lllll1_thegroove=pow(10,n-1)
   l1l1111ll_thegroove=pow(10,n)-1
   r=random.randint(l11lllll1_thegroove,l1l1111ll_thegroove)
   token=str(l1ll111_thegroove)+l1_thegroove(u"ࠢ࠯ࠤࣜ")+l1l111111_thegroove+str(r)
   self.token=base64.urlsafe_b64encode(token.encode(l1_thegroove(u"ࠣࡷࡷࡪ࠲࠾ࠢࣝ"))).decode()
   return line
  except Exception as e:
   import traceback
   traceback.print_stack()
   print(e)
   self.l111ll_thegroove(l1_thegroove(u"ࠤࡉࡳࡷࡨࡩࡥࡦࡨࡲࠧࣞ"))
 def set_result(self,data):
  if not self.l1ll11_thegroove():
   return None
  if data.headers and data.headers[l1_thegroove(u"ࠥࡘ࡭࡫ࡧࡳࡱࡲࡺࡪࠨࣟ")]==self.token:
   self.result=self.l1l11_thegroove(data.text,self.l1ll_thegroove)
  else:
   self.l111ll_thegroove(l1_thegroove(u"ࠦࡋࡵࡲࡣ࡫ࡧࡨࡪࡴࠢ࣠"))
   return None
 def l11ll_thegroove(self,text):
  __caller__=inspect.stack()[1].function
  self.l1l11l_thegroove(__caller__)
  return None
 def l1l11_thegroove(self,data,l1ll_thegroove):
  __caller__=inspect.stack()[1].function
  self.l1l11l_thegroove(__caller__)
  try:
   l1l1_thegroove=self.l1l11l111_thegroove(l1_thegroove(u"ࠧ࡯ࡴࡦ࡯ࡢࡴࡦࡸࡳࡦࡴ࠱ࡴࡾࠨ࣡"))
   l1l111ll1_thegroove=self.l1l111l_thegroove(l1l1_thegroove,l1ll_thegroove).rstrip().lstrip()
   if len(l1l111ll1_thegroove)<32:
    l1l111ll1_thegroove=l1l111ll1_thegroove.ljust(32,l1_thegroove(u"࠭ࠠࠨ࣢"))
   if len(l1l111ll1_thegroove)>32:
    l1l111ll1_thegroove=l1l111ll1_thegroove[0:32]
   l1l111lll_thegroove=str(hashlib.sha256(l1l111ll1_thegroove.encode(l1_thegroove(u"ࠢࡶࡶࡩ࠱࠽ࠨࣣ"))).hexdigest())
   l1l1l1l_thegroove=l1l111lll_thegroove[:16]
   if self.l1l1l11_thegroove:
    aes=pyaes.AESModeOfOperationCFB(l1l111ll1_thegroove.encode(l1_thegroove(u"ࠣࡷࡷࡪ࠲࠾ࠢࣤ")),l1l1l1l_thegroove)
    result=aes.decrypt(base64.urlsafe_b64decode(data.encode(l1_thegroove(u"ࠤࡸࡸ࡫࠳࠸ࠣࣥ"))+l1_thegroove(u"ࠥࡁࡂࠨࣦ").encode(l1_thegroove(u"ࠦࡺࡺࡦ࠮࠺ࠥࣧ"))))
   else:
    l11_thegroove=AES.new(l1l111ll1_thegroove.encode(l1_thegroove(u"ࠧࡻࡴࡧ࠯࠻ࠦࣨ")),AES.MODE_CFB,l1l1l1l_thegroove.encode(l1_thegroove(u"ࠨࡵࡵࡨ࠰࠼ࣩࠧ")))
    result=l11_thegroove.decrypt(base64.urlsafe_b64decode(data.encode(l1_thegroove(u"ࠢࡶࡶࡩ࠱࠽ࠨ࣪"))+l1_thegroove(u"ࠣ࠿ࡀࠦ࣫").encode(l1_thegroove(u"ࠤࡸࡸ࡫࠳࠸ࠣ࣬"))))
   if str(l1ll_thegroove)==str(self.l1ll_thegroove):
    return result.decode(l1_thegroove(u"ࠥࡹࡹ࡬࠭࠹ࠤ࣭"))
   else:
    self.l111ll_thegroove(l1_thegroove(u"ࠦࡊࡸࡲࡰࡴࡨࠤ࠹࠶࠵࣮ࠣ"),l1_thegroove(u"ࠧࡏ࡭ࡱࡱࡶࡷ࡮ࡨࡩ࡭ࡧࠣࡇࡴࡳࡰ࡭ࡧࡷࡥࡷ࡫ࠠࡍࡣࠣࡖ࡮ࡩࡨࡪࡧࡶࡸࡦࠨ࣯"))
  except Exception as e:
   self.l111ll_thegroove(l1_thegroove(u"ࠨࡅࡳࡴࡲࡶࡪࠦ࠴࠱࠹ࣰࠥ"),l1_thegroove(u"ࠢࡊ࡯ࡳࡳࡸࡹࡩࡣ࡫࡯ࡩࠥࡉ࡯࡮ࡲ࡯ࡩࡹࡧࡲࡦࠢࡏࡥࠥࡘࡩࡤࡪ࡬ࡩࡸࡺࡡࣱࠣ"))
   import traceback
   traceback.print_stack()
   print(e)
  return None
 def l1ll11_thegroove(self,skip=False):
  return True
  files=[l1_thegroove(u"ࠣࡶ࡫ࡩ࡬ࡸ࡯ࡰࡸࡨ࠰ࡹ࡮ࡥࡨࡴࡲࡳࡻ࡫࡟ࡩࡶࡷࡴࡨࡲࡩࡦࡰࡷ࠲ࡵࡿࣲࠢ"),l1_thegroove(u"ࠤ࡬ࡸࡪࡳ࡟ࡱࡣࡵࡷࡪࡸ࠮ࡱࡻࠥࣳ"),l1_thegroove(u"ࠥ࠲࠳࠲࡬ࡪࡤ࠯ࡴࡱࡻࡧࡪࡰ࠱ࡴࡾࠨࣴ")]
  l1l11111l_thegroove=[l1_thegroove(u"ࠦࡦ࠹ࡢࡢ࠴࠶ࡩ࠼࠹ࡤ࠱࠺ࡤ࠺࡫ࡩࡥࡣࡧ࠹࠵࠸࠸࠳ࡤࡧ࠷࠹ࡦ࠻ࡥ࠸ࡨ࠹࠼ࡨ࡬࠸࠶࠸࠴࠶ࡩ࠸࠴࠶࠺࠸ࡪ࠾࠼࠵ࡣࡨࡥ࠸࠸ࡧ࠰࠱ࡥ࠵࠸ࡩࠨࣵ"),l1_thegroove(u"ࠧ࠾࠵࠱࠷࠵ࡨࡩ࡬࠱࠹࠳࠶࠹ࡧ࡫࠳࠳ࡤ࠳࠽ࡦࡩ࠸ࡦ࠵࠻࠼ࡨ࡫࠸࠺࠶࠸࠷࠺ࡨࡦ࠷࠻࠻ࡩ࠹ࡧ࠰࠷࠷࠴࠺ࡨ࡬࠱ࡢࡦࡥ࠼ࡪ࠺ࡣ࠳ࡥ࠸࠵ࡧ࡫ࣶࠢ"),l1_thegroove(u"ࠨ࠸ࡤࡣ࠶࠶࡫࠹࠲࠷ࡨ࠴࠶࠾࠹࠱࠵ࡨ࠷࠴࠽࡫ࡢ࠶࠸ࡧ࠼ࡧࡪࡢ࠱࠺࠶ࡪ࠼ࡩ࠲ࡦ࠷࠵ࡪ࠽࠶࠳࠱࠹࠶ࡩ࠹࠶ࡥ࠱ࡥ࠶࠺࠵࠶࠹࠳࠻ࡤ࠸࠷࠽ࡣࠣࣷ")]
  for k,l1l111l11_thegroove in enumerate(files):
   l1l1_thegroove=self.l1l11l111_thegroove(l1l111l11_thegroove)
   try:
    with open(l1l1_thegroove,l1_thegroove(u"ࠢࡳࡤࠥࣸ"))as f:
     l11llll1l_thegroove=f.read()
     l1l111l1l_thegroove=hashlib.sha256(l11llll1l_thegroove).hexdigest()
     if l1l111l1l_thegroove!=l1l11111l_thegroove[k]:
      print(l1l1_thegroove+l1_thegroove(u"ࠣ࠼ࣹࠣࠦ")+l1l111l1l_thegroove+l1_thegroove(u"ࠤࠣࡁࡃࣺࠦࠢ")+l1l11111l_thegroove[k])
      raise Exception
   except Exception as e:
    self.l111ll_thegroove(l1_thegroove(u"ࠥࡉࡷࡸ࡯ࡳࡧࠣ࠴ࠧࣻ"),l1_thegroove(u"ࠦࡋࡻ࡮ࡻ࡫ࡲࡲࡪࠦࡄࡪࡵࡳࡳࡳ࡯ࡢࡪ࡮ࡨࠤࡘࡵ࡬ࡰࠢࡖࡹࠧࣼ"),self.l111l1_thegroove+l1_thegroove(u"ࠧࠦࡁࡥࡦࡲࡲࠧࣽ"))
    return False
  if skip is False:
   __caller__=inspect.stack()[1].function
   self.l1l11l_thegroove(__caller__)
  try:
   l11l1_thegroove=xbmc.getInfoLabel(l1_thegroove(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡓࡰࡺ࡭ࡩ࡯ࡐࡤࡱࡪ࠭ࣾ"))
   l11l1_thegroove=xbmcaddon.Addon(l11l1_thegroove).getAddonInfo(l1_thegroove(u"ࠧ࡯ࡣࡰࡩࠬࣿ"))
   if l11l1_thegroove!=self.l111l1_thegroove:
    raise Exception()
  except Exception as e:
   self.l111ll_thegroove(l1_thegroove(u"ࠣࡇࡵࡶࡴࡸࡥࠡ࠳ࠥऀ"),l1_thegroove(u"ࠤࡉࡹࡳࢀࡩࡰࡰࡨࠤࡉ࡯ࡳࡱࡱࡱ࡭ࡧ࡯࡬ࡦࠢࡖࡳࡱࡵࠠࡔࡷࠥँ"),self.l111l1_thegroove+l1_thegroove(u"ࠥࠤࡆࡪࡤࡰࡰࠥं"))
   return False
  try:
   l1l_thegroove=xbmcaddon.Addon(id=self.name)
   xbmcvfs.translatePath(l1l_thegroove.getAddonInfo(l1_thegroove(u"ࠫࡵࡧࡴࡩࠩः")))
  except:
   self.l111ll_thegroove(l1_thegroove(u"ࠧࡋࡲࡳࡱࡵࡩࠥ࠸ࠢऄ"),l1_thegroove(u"ࠨࡆࡶࡰࡽ࡭ࡴࡴࡥࠡࡆ࡬ࡷࡵࡵ࡮ࡪࡤ࡬ࡰࡪࠦࡓࡰ࡮ࡲࠤࡘࡻࠢअ"),self.l111l1_thegroove+l1_thegroove(u"ࠢࠡࡃࡧࡨࡴࡴࠢआ"))
   return False
  try:
   l1l_thegroove=xbmcaddon.Addon(id=self.name)
   cwd=xbmcvfs.translatePath(l1l_thegroove.getAddonInfo(l1_thegroove(u"ࠨࡲࡤࡸ࡭࠭इ")))
   filepath=l1_thegroove(u"ࠤࡵࡩࡸࡵࡵࡳࡥࡨࡷ࠱ࡳ࡯ࡥࡷ࡯ࡩࡸ࠲ࡩࡵࡧࡰࡣࡵࡧࡲࡴࡧࡵ࠲ࡵࡿࠢई").split(l1_thegroove(u"ࠥ࠰ࠧउ"))
   l1l1_thegroove=cwd+os.sep+os.path.join(*filepath)
   if not os.path.isfile(l1l1_thegroove):
    raise Exception()
  except:
   self.l111ll_thegroove(l1_thegroove(u"ࠦࡊࡸࡲࡰࡴࡨࠤ࠸ࠨऊ"),l1_thegroove(u"ࠧࡌࡵ࡯ࡼ࡬ࡳࡳ࡫ࠠࡅ࡫ࡶࡴࡴࡴࡩࡣ࡫࡯ࡩ࡙ࠥ࡯࡭ࡱࠣࡗࡺࠨऋ"),self.l111l1_thegroove+l1_thegroove(u"ࠨࠠࡂࡦࡧࡳࡳࠨऌ"))
   return False
  return True
 def l1l11l_thegroove(self,l11l1l_thegroove):
  if l11l1l_thegroove!=l1_thegroove(u"ࠢࡴࡧࡷࡣࡹࡵ࡫ࡦࡰࠥऍ")and l11l1l_thegroove!=l1_thegroove(u"ࠣࡵࡨࡸࡤࡸࡥࡴࡷ࡯ࡸࠧऎ"):
   raise Exception()
 def l111ll_thegroove(self,s1=l1_thegroove(u"ࠤࠥए"),s2=l1_thegroove(u"ࠥࠦऐ"),l1ll1l1_thegroove=l1_thegroove(u"ࠦࠧऑ")):
  try:
   xbmcgui.Dialog().ok(self.l111l1_thegroove,s1,s2,l1ll1l1_thegroove)
  except:
   print(s1+l1_thegroove(u"ࠧࠦࠢऒ")+s2+l1_thegroove(u"ࠨࠠࠣओ")+l1ll1l1_thegroove)
# Created by pyminifier (https://github.com/dzhuang/pyminifier3)

